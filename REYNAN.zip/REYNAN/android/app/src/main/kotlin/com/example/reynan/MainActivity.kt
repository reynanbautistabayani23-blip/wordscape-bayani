package com.example.reynan

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
