import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(const WordPuzzleApp());
}

class WordPuzzleApp extends StatelessWidget {
  const WordPuzzleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Word Puzzle',
      theme: ThemeData(
        fontFamily: 'Arial',
        useMaterial3: true,
      ),
      home: const WordGamePage(),
    );
  }
}

class Level {
  final String letters;
  final List<String> words;

  const Level({
    required this.letters,
    required this.words,
  });
}

const List<Level> levels = [
  Level(
    letters: 'APPLE',
    words: [
      'APPLE',
      'PEAL',
      'PALE',
      'LEAP',
      'PLEA',
      'PEP',
    ],
  ),
  Level(
    letters: 'STONE',
    words: [
      'STONE',
      'NOTES',
      'TONES',
      'ONSET',
      'ONES',
      'NOTE',
      'TONE',
    ],
  ),
  Level(
    letters: 'TRAIN',
    words: [
      'TRAIN',
      'RAIN',
      'NAIL',
      'TAIL',
      'TRAIL',
      'ANTI',
      'RANT',
    ],
  ),
  Level(
    letters: 'HOUSE',
    words: [
      'HOUSE',
      'SHOE',
      'HOSE',
      'USE',
      'SHE',
      'SUE',
    ],
  ),
  Level(
    letters: 'PLANT',
    words: [
      'PLANT',
      'PLAN',
      'PANT',
      'PLAT',
      'TAN',
      'NAP',
      'ANT',
    ],
  ),
];

class WordGamePage extends StatefulWidget {
  const WordGamePage({super.key});

  @override
  State<WordGamePage> createState() => _WordGameState();
}

class _WordGameState extends State<WordGamePage>
    with SingleTickerProviderStateMixin {
  int levelIndex = 0;
  int score = 0;
  int bestScore = 0;

  String currentWord = '';

  final List<String> foundWords = [];

  late List<String> shuffledLetters;

  final Random random = Random();

  @override
  void initState() {
    super.initState();
    _loadLevel();
  }

  void _loadLevel() {
    shuffledLetters = levels[levelIndex].letters.split('');
    shuffledLetters.shuffle(random);

    currentWord = '';
    foundWords.clear();
  }

  void _nextLevel() {
    if (levelIndex < levels.length - 1) {
      setState(() {
        levelIndex++;
        _loadLevel();
      });
    } else {
      _showFinishedDialog();
    }
  }

  void _shuffleLetters() {
    setState(() {
      shuffledLetters.shuffle(random);
    });
  }

  void _addLetter(String letter) {
    if (currentWord.length >= shuffledLetters.length) {
      return;
    }

    setState(() {
      currentWord += letter;
    });
  }

  void _removeLastLetter() {
    if (currentWord.isEmpty) {
      return;
    }

    setState(() {
      currentWord =
          currentWord.substring(0, currentWord.length - 1);
    });
  }

  void _submitWord() {
    if (currentWord.isEmpty) {
      _showMessage('Enter a word first!');
      return;
    }

    final word = currentWord.toUpperCase();

    if (!levels[levelIndex].words.contains(word)) {
      _showMessage('Not a valid word');
      setState(() {
        currentWord = '';
      });
      return;
    }

    if (foundWords.contains(word)) {
      _showMessage('Already found!');
      setState(() {
        currentWord = '';
      });
      return;
    }

    setState(() {
      foundWords.add(word);
      score += word.length * 10;

      if (score > bestScore) {
        bestScore = score;
      }

      currentWord = '';
    });

    _showMessage(
      '+${word.length * 10} points!',
      success: true,
    );

    if (foundWords.length == levels[levelIndex].words.length) {
      Future.delayed(
        const Duration(milliseconds: 500),
            () {
          if (mounted) {
            _showLevelComplete();
          }
        },
      );
    }
  }

  void _useHint() {
    final remaining = levels[levelIndex].words
        .where((word) => !foundWords.contains(word))
        .toList();

    if (remaining.isEmpty) {
      return;
    }

    final hint = remaining[random.nextInt(remaining.length)];

    setState(() {
      score = max(0, score - 20);
    });

    _showMessage(
      'Try: ${hint[0]}...',
      success: true,
    );
  }

  void _showMessage(
      String message, {
        bool success = false,
      }) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              success
                  ? Icons.check_circle_rounded
                  : Icons.info_rounded,
              color: Colors.white,
            ),
            const SizedBox(width: 10),
            Text(
              message,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        behavior: SnackBarBehavior.floating,
        backgroundColor: success
            ? const Color(0xFF00C853)
            : const Color(0xFF30345C),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        margin: const EdgeInsets.all(18),
      ),
    );
  }

  // ------------------------------------------------------------
  // LEVEL COMPLETE DIALOG
  // ------------------------------------------------------------

  void _showLevelComplete() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  Color(0xFF00C853),
                  Color(0xFF64DD17),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(
                  color: Colors.greenAccent.withOpacity(0.4),
                  blurRadius: 30,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Trophy
                Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.18),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.emoji_events_rounded,
                    color: Colors.amber,
                    size: 60,
                  ),
                ),

                const SizedBox(height: 18),

                const Text(
                  'LEVEL CLEAR!',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                  ),
                ),

                const SizedBox(height: 8),

                Text(
                  'Level ${levelIndex + 1} completed!',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 17,
                    fontWeight: FontWeight.w600,
                  ),
                ),

                const SizedBox(height: 20),

                // Points
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 22,
                    vertical: 11,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.18),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                    ),
                  ),
                  child: Text(
                    '+${foundWords.fold<int>(
                      0,
                          (sum, word) => sum + word.length * 10,
                    )} POINTS',
                    style: const TextStyle(
                      color: Colors.amber,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),

                const SizedBox(height: 25),

                // Next Level Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                      _nextLevel();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color(0xFF00A844),
                      elevation: 5,
                      padding: const EdgeInsets.symmetric(
                        vertical: 16,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    child: Text(
                      levelIndex < levels.length - 1
                          ? 'NEXT LEVEL'
                          : 'FINISH',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ------------------------------------------------------------
  // ALL LEVELS COMPLETE
  // ------------------------------------------------------------

  void _showFinishedDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  Color(0xFFFFB300),
                  Color(0xFFFF6F00),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(28),
              boxShadow: [
                BoxShadow(
                  color: Colors.orangeAccent.withOpacity(0.4),
                  blurRadius: 30,
                  spreadRadius: 5,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.workspace_premium_rounded,
                  color: Colors.white,
                  size: 80,
                ),

                const SizedBox(height: 15),

                const Text(
                  'ALL LEVELS COMPLETE!',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 25,
                    fontWeight: FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 12),

                Text(
                  'Amazing work!',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),

                const SizedBox(height: 20),

                Text(
                  'Score: $score',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 25),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);

                      setState(() {
                        levelIndex = 0;
                        score = 0;
                        _loadLevel();
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.deepOrange,
                      padding: const EdgeInsets.symmetric(
                        vertical: 16,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    child: const Text(
                      'PLAY AGAIN',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ------------------------------------------------------------
  // BACKGROUND
  // ------------------------------------------------------------

  Widget _background() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFF10132B),
            Color(0xFF202456),
            Color(0xFF10132B),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------
  // TOP BAR
  // ------------------------------------------------------------

  Widget _topBar() {
    return Row(
      children: [
        Expanded(
          child: _infoCard(
            icon: Icons.layers_rounded,
            title: 'LEVEL',
            value: '${levelIndex + 1}/${levels.length}',
          ),
        ),

        const SizedBox(width: 10),

        Expanded(
          child: _infoCard(
            icon: Icons.stars_rounded,
            title: 'SCORE',
            value: '$score',
          ),
        ),

        const SizedBox(width: 10),

        Expanded(
          child: _infoCard(
            icon: Icons.lightbulb_rounded,
            title: 'HINT',
            value: '-20',
            onTap: _useHint,
          ),
        ),
      ],
    );
  }

  Widget _infoCard({
    required IconData icon,
    required String title,
    required String value,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: 12,
          horizontal: 8,
        ),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.07),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: Colors.white.withOpacity(0.08),
          ),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              color: Colors.amberAccent,
              size: 23,
            ),

            const SizedBox(height: 4),

            Text(
              title,
              style: TextStyle(
                color: Colors.white.withOpacity(0.55),
                fontSize: 10,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),

            const SizedBox(height: 2),

            Text(
              value,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------
  // CURRENT WORD
  // ------------------------------------------------------------

  Widget _currentWordBox() {
    return Container(
      width: double.infinity,
      height: 72,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.07),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withOpacity(0.1),
        ),
      ),
      child: Center(
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 150),
          child: Text(
            currentWord.isEmpty ? 'MAKE A WORD' : currentWord,
            key: ValueKey(currentWord),
            style: TextStyle(
              color: currentWord.isEmpty
                  ? Colors.white.withOpacity(0.35)
                  : Colors.white,
              fontSize: currentWord.isEmpty ? 14 : 27,
              fontWeight: FontWeight.w900,
              letterSpacing: 5,
            ),
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------------
  // WORD GRID
  // ------------------------------------------------------------

  Widget _wordGrid() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.055),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
        ),
      ),
      child: Wrap(
        spacing: 9,
        runSpacing: 10,
        alignment: WrapAlignment.center,
        children: levels[levelIndex].words.map((word) {
          final found = foundWords.contains(word);

          return _wordTile(
            word: word,
            found: found,
          );
        }).toList(),
      ),
    );
  }

  Widget _wordTile({
    required String word,
    required bool found,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      width: 82,
      height: 42,
      decoration: BoxDecoration(
        color: found
            ? const Color(0xFF00C853).withOpacity(0.85)
            : Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: found
              ? Colors.greenAccent.withOpacity(0.5)
              : Colors.white.withOpacity(0.1),
        ),
        boxShadow: found
            ? [
          BoxShadow(
            color: Colors.greenAccent.withOpacity(0.18),
            blurRadius: 10,
          ),
        ]
            : null,
      ),
      child: Center(
        child: found
            ? Text(
          word,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.w900,
            letterSpacing: 1,
          ),
        )
            : Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            word.length,
                (index) => Container(
              margin: const EdgeInsets.symmetric(
                horizontal: 2,
              ),
              width: 7,
              height: 2,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.35),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------------
  // ACTION BUTTONS
  // ------------------------------------------------------------

  Widget _actionButtons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _smallActionButton(
          icon: Icons.backspace_rounded,
          label: 'DELETE',
          onTap: _removeLastLetter,
        ),

        const SizedBox(width: 16),

        GestureDetector(
          onTap: _submitWord,
          child: Container(
            width: 82,
            height: 82,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [
                  Color(0xFF7C4DFF),
                  Color(0xFF536DFE),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.deepPurpleAccent.withOpacity(0.4),
                  blurRadius: 20,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: const Icon(
              Icons.check_rounded,
              color: Colors.white,
              size: 38,
            ),
          ),
        ),

        const SizedBox(width: 16),

        _smallActionButton(
          icon: Icons.shuffle_rounded,
          label: 'SHUFFLE',
          onTap: _shuffleLetters,
        ),
      ],
    );
  }

  Widget _smallActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 55,
            height: 55,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.white.withOpacity(0.1),
              ),
            ),
            child: Icon(
              icon,
              color: Colors.white.withOpacity(0.85),
              size: 24,
            ),
          ),

          const SizedBox(height: 6),

          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.4),
              fontSize: 9,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------
  // LETTER WHEEL
  // ------------------------------------------------------------

  Widget _letterWheel() {
    return SizedBox(
      width: 300,
      height: 300,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            width: 275,
            height: 275,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.035),
              border: Border.all(
                color: Colors.white.withOpacity(0.08),
                width: 2,
              ),
            ),
          ),

          ..._buildLetterWheel(),
        ],
      ),
    );
  }

  List<Widget> _buildLetterWheel() {
    final widgets = <Widget>[];

    final centerX = 150.0;
    final centerY = 150.0;
    final radius = 95.0;

    for (int i = 0; i < shuffledLetters.length; i++) {
      final angle =
          (2 * pi * i / shuffledLetters.length) - pi / 2;

      final x = centerX + radius * cos(angle) - 31;
      final y = centerY + radius * sin(angle) - 31;

      widgets.add(
        Positioned(
          left: x,
          top: y,
          child: _letterButton(
            shuffledLetters[i],
          ),
        ),
      );
    }

    return widgets;
  }

  Widget _letterButton(String letter) {
    return GestureDetector(
      onTap: () {
        _addLetter(letter);
      },
      child: Container(
        width: 62,
        height: 62,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
            colors: [
              Color(0xFF4A4F91),
              Color(0xFF292D65),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: Colors.white.withOpacity(0.16),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.25),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Center(
          child: Text(
            letter,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 25,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------------
  // BUILD
  // ------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _background(),

          SafeArea(
            child: LayoutBuilder(
              builder: (context, constraints) {
                return SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(
                    18,
                    14,
                    18,
                    25,
                  ),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      minHeight: constraints.maxHeight - 39,
                    ),
                    child: Column(
                      children: [
                        _topBar(),

                        const SizedBox(height: 18),

                        _currentWordBox(),

                        const SizedBox(height: 16),

                        _wordGrid(),

                        const SizedBox(height: 12),

                        _letterWheel(),

                        const SizedBox(height: 4),

                        _actionButtons(),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}